-- prepares a MySQL server for the project

CREATE DATABASE IF NOT EXISTS hb_dev;
