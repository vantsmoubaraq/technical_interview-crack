$(document).ready( function() {$('#action').click(
  function(event){
     /*var id = $("#pt").text();*/
     var id = window.location.pathname.split('/')[2];
     var route = `http://100.26.246.254:5001/api/v1/pharmacy/${id}`;
   $.ajax(
           {
                   url: route,
                   type: 'DELETE',
                   success: function(result){
                        console.log('Deleted Successfully');
                        window.location.href = `http://healthbridge.techaccess.tech/pharmacy`;
                   },
                   error: function(xhr, status, error ) {
                           console.log(error);
                           console.log(id);

                   }
           }
   );
  }
);});
