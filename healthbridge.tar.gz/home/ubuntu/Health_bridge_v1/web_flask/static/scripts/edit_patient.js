document.getElementById("btn").addEventListener(
'click', function(event) {
event.preventDefault();
const form = document.getElementById("myForm");
const formdata = new FormData(form);

const data = {};
for (const [key, value] of formdata.entries()){
  data[key] = value;
}

const id = window.location.pathname.split("/")[2]

const submit_data = {
method: 'PUT',
body: JSON.stringify(data),
headers: {'Content-Type': 'application/json'}
};

const url = 'http://100.26.246.254:5001/api/v1/patients/' + id;

fetch( url, submit_data
).then(response => response.json()).then(
data => {console.log(data);
window.location.href = `http://healthbridge.techaccess.tech/single/${id}`;}
).catch(error => console.error(error))
});
